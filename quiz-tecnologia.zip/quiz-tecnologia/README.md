# Quiz de Tecnologia

Quiz interativo em HTML, CSS e JavaScript puro. A versão 1 traz 5 perguntas; a estrutura já está pronta para chegar a 50 e para futura integração com backend.

## Como executar

Não precisa instalar nada. Escolha uma opção:

1. **Direto no navegador:** abra o arquivo `index.html` com duplo clique.
2. **Servidor local (recomendado):** na pasta do projeto, rode

   ```bash
   python -m http.server 8000
   ```

   e acesse http://localhost:8000.

## Regras

- O quiz começa ao clicar em "Iniciar quiz".
- Uma pergunta por vez, com 50 segundos para responder.
- Acertos pontuam pelo tempo restante; resposta errada vale 1 ponto (`CONFIG.WRONG_ANSWER_POINTS`) e tempo esgotado vale 0:

| Tempo restante | Pontos |
| --- | ---: |
| 50 a 40 s | 10 |
| < 40 a 35 s | 8 |
| < 35 a 25 s | 6 |
| < 25 a 15 s | 4 |
| < 15 a 1 s | 3 |
| Tempo esgotado | 0 |

## Estrutura

```text
quiz-tecnologia/
├── index.html
├── css/style.css
├── js/
│   ├── questions.js   # dados das perguntas + loadQuestions()
│   └── script.js      # lógica do quiz
└── README.md
```

## Como adicionar perguntas

Inclua novos objetos no array `LOCAL_QUESTIONS` em `js/questions.js`:

```js
{ id: 6, question: "...", options: ["...", "...", "...", "..."], correctAnswer: 0 }
```

`correctAnswer` é o índice da alternativa correta na lista `options`. O campo opcional `source` (URL) aparece como link de "Fonte" depois que a pergunta é respondida. A ordem das alternativas é embaralhada a cada partida (`CONFIG.SHUFFLE_OPTIONS` em `script.js`).

## Preparação para backend

- **Carregar perguntas:** troque o corpo de `loadQuestions()` (em `questions.js`) por um `fetch` à API.
- **Salvar partida:** `buildMatchPayload()` já monta jogador, respostas escolhidas, acertos/erros, tempo por pergunta, pontos por pergunta, pontuação final e data/hora. Basta implementar o `fetch` dentro de `saveMatch()`.
- **Jogador:** `state.playerId` é o ponto de entrada para a identificação futura.
- A lógica de negócio (pontuação, validação, resumo) é independente do DOM; só a seção "Interface" de `script.js` toca o HTML.
