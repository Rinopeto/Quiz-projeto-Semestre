"use strict";

/*
 * Dados das perguntas (v1: 5 perguntas do arquivo Tech Quiz.docx).
 * correctAnswer é o índice da alternativa correta dentro de "options".
 * Para chegar a 50 perguntas, basta acrescentar novos objetos a este array.
 */
const LOCAL_QUESTIONS = [
  {
    id: 1,
    category: "História da tecnologia",
    question: "Qual máquina é amplamente considerada o primeiro computador digital eletrônico de propósito geral e em qual década ela foi operacionalizada?",
    options: ["ENIAC", "Colossus", "Z3", "ABC"],
    correctAnswer: 0,
    source: "https://penntoday.upenn.edu/news/worlds-first-general-purpose-computer-turns-75"
  },
  {
    id: 2,
    category: "História da tecnologia",
    question: "Quem inventou a World Wide Web (WWW) no laboratório do CERN em 1989?",
    options: ["Tim Berners-Lee", "Linus Torvalds", "Marc Andreessen", "Richard Stallman"],
    correctAnswer: 0,
    source: "https://home.cern/science/computing/birth-web/short-history-web"
  },
  {
    id: 3,
    category: "História da tecnologia",
    question: "Qual opção Tim Berners-Lee não criou?",
    options: ["CSS", "HTTP", "HTML", "URL"],
    correctAnswer: 0,
    source: "https://www.infoescola.com/informatica/cascading-style-sheets-css/"
  },
  {
    id: 4,
    category: "História da tecnologia",
    question: "O termo \"bug\" na computação se popularizou quando Grace Hopper documentou uma lagartixa real presa em um relé do computador Harvard Mark II. Essa afirmação é verdadeira ou falsa?",
    options: ["Falsa", "Verdadeira"],
    correctAnswer: 0,
    source: "https://www.educamaisbrasil.com.br/educacao/dicas/o-que-e-bug-qual-a-origem-da-expressao"
  },
  {
    id: 5,
    category: "História da tecnologia",
    question: "Qual o primeiro vírus de computador da história geral da tecnologia?",
    options: ["Creeper", "Brain", "ILOVEYOU", "WannaCry"],
    correctAnswer: 0,
    source: "https://www.cybersecbrazil.com.br/post/o-creeper-o-primeiro-v%C3%ADrus-de-computador-da-hist%C3%B3ria"
  }
];

/*
 * Camada de acesso aos dados.
 * Hoje devolve o array local; no futuro, basta trocar o corpo por uma chamada à API:
 *
 *   const response = await fetch("/api/questions");
 *   if (!response.ok) throw new Error("Falha ao carregar perguntas");
 *   return response.json();
 *
 * O restante da aplicação só depende deste contrato: retornar uma Promise
 * com um array de { id, question, options[], correctAnswer }.
 */
async function loadQuestions() {
  return LOCAL_QUESTIONS.map((q) => ({ ...q, options: [...q.options] }));
}
