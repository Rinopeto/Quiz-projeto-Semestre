"use strict";

/* =========================================================
 * Configuração
 * ========================================================= */
const CONFIG = {
  SECONDS_PER_QUESTION: 50,
  WARNING_SECONDS: 10,
  MAX_POINTS_PER_QUESTION: 10,
  WRONG_ANSWER_POINTS: 1, // pontos por resposta errada (tempo esgotado continua valendo 0)
  SHUFFLE_OPTIONS: true, // embaralha a ordem das alternativas a cada partida
  OPTION_LABELS: ["A", "B", "C", "D", "E", "F"]
};

// Faixas de pontuação: tempo restante mínimo (segundos) => pontos.
// Abaixo da última faixa (e acima de 0) valem 3 pontos; tempo esgotado vale 0.
// Resposta errada vale CONFIG.WRONG_ANSWER_POINTS, independentemente do tempo.
const SCORE_TIERS = [
  { minSeconds: 40, points: 10 },
  { minSeconds: 35, points: 8 },
  { minSeconds: 25, points: 6 },
  { minSeconds: 15, points: 4 }
];
const LOWEST_POINTS = 3;

/* =========================================================
 * Estado da partida (sem referências ao DOM)
 * ========================================================= */
const state = {
  playerId: null, // futuramente: identificação do jogador
  questions: [],
  currentIndex: 0,
  totalScore: 0,
  results: [], // um registro por pergunta respondida/expirada
  selectedOption: null, // índice ORIGINAL da alternativa selecionada
  status: "idle", // idle | answering | answered | timeout
  startedAt: null,
  questionStartedAt: null
};

/* =========================================================
 * Serviços / dados (ponto de integração com o backend)
 * ========================================================= */
function shuffle(array) {
  const copy = [...array];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

// Cada alternativa guarda seu índice original, então embaralhar não afeta correctAnswer.
function prepareQuestions(rawQuestions) {
  return rawQuestions.map((q) => {
    const options = q.options.map((text, originalIndex) => ({ text, originalIndex }));
    return { ...q, options: CONFIG.SHUFFLE_OPTIONS ? shuffle(options) : options };
  });
}

// Monta o payload que futuramente será enviado ao backend.
function buildMatchPayload() {
  return {
    playerId: state.playerId,
    startedAt: state.startedAt,
    finishedAt: new Date().toISOString(),
    totalScore: state.totalScore,
    summary: getSummary(),
    answers: state.results
  };
}

// Stub: trocar por fetch("/api/matches", { method: "POST", ... }) quando houver backend.
async function saveMatch(payload) {
  console.info("[quiz] Partida finalizada (payload pronto para o backend):", payload);
}

/* =========================================================
 * Regras de negócio (funções puras)
 * ========================================================= */
function calculatePoints(secondsLeft) {
  if (secondsLeft <= 0) return 0;
  const tier = SCORE_TIERS.find((t) => secondsLeft >= t.minSeconds);
  return tier ? tier.points : LOWEST_POINTS;
}

function isCorrect(question, selectedOriginalIndex) {
  return selectedOriginalIndex === question.correctAnswer;
}

function getSummary() {
  const correct = state.results.filter((r) => r.status === "correct").length;
  const wrong = state.results.filter((r) => r.status === "incorrect").length;
  const timeouts = state.results.filter((r) => r.status === "timeout").length;
  return {
    totalQuestions: state.questions.length,
    correct,
    wrong,
    answered: correct + wrong,
    timeouts,
    maxScore: state.questions.length * CONFIG.MAX_POINTS_PER_QUESTION
  };
}

/* =========================================================
 * Cronômetro (independente do DOM)
 * ========================================================= */
const timer = {
  intervalId: null,
  deadline: 0,

  start(seconds, onTick, onExpire) {
    this.stop();
    this.deadline = Date.now() + seconds * 1000;
    const tick = () => {
      const remaining = Math.max(0, (this.deadline - Date.now()) / 1000);
      onTick(remaining);
      if (remaining <= 0) {
        this.stop();
        onExpire();
      }
    };
    tick();
    this.intervalId = setInterval(tick, 100);
  },

  stop() {
    clearInterval(this.intervalId);
    this.intervalId = null;
  },

  // Segundos restantes neste instante
  remaining() {
    return Math.max(0, (this.deadline - Date.now()) / 1000);
  }
};

/* =========================================================
 * Interface (única camada que toca o DOM)
 * ========================================================= */
const $ = (id) => document.getElementById(id);
const ui = {
  screens: {
    start: $("screen-start"),
    loading: $("screen-loading"),
    error: $("screen-error"),
    quiz: $("screen-quiz"),
    result: $("screen-result")
  },
  errorMessage: $("error-message"),
  progressText: $("progress-text"),
  progressBar: $("progress-bar"),
  totalScore: $("total-score"),
  timer: $("timer"),
  timerValue: $("timer-value"),
  timerPoints: $("timer-points"),
  timerBar: $("timer-bar"),
  questionText: $("question-text"),
  options: $("options"),
  feedback: $("feedback"),
  source: $("source"),
  sourceLink: $("source-link"),
  questionPoints: $("question-points"),
  actionBtn: $("action-btn"),
  startBtn: $("start-btn"),
  retryBtn: $("retry-btn"),
  restartBtn: $("restart-btn")
};

function showScreen(name) {
  Object.entries(ui.screens).forEach(([key, el]) => {
    el.hidden = key !== name;
  });
}

function renderQuestion(question, index, total) {
  ui.progressText.textContent = `Pergunta ${index + 1} de ${total}`;
  ui.progressBar.style.width = `${(index / total) * 100}%`;
  ui.totalScore.textContent = state.totalScore;
  ui.questionText.textContent = question.question;
  ui.questionPoints.textContent = "–";
  ui.feedback.hidden = true;
  ui.feedback.className = "feedback";
  ui.source.hidden = true; // a fonte só aparece depois da resposta, para não entregar a solução
  ui.actionBtn.textContent = "Confirmar resposta";
  ui.actionBtn.disabled = true;

  ui.options.replaceChildren();
  question.options.forEach((opt, position) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "option";
    btn.dataset.index = opt.originalIndex;
    btn.setAttribute("role", "radio");
    btn.setAttribute("aria-checked", "false");

    const label = document.createElement("span");
    label.className = "option-label";
    label.textContent = CONFIG.OPTION_LABELS[position] || position + 1;

    const text = document.createElement("span");
    text.textContent = opt.text;

    btn.append(label, text);
    ui.options.appendChild(btn);
  });
}

function renderTimer(secondsLeft) {
  const total = CONFIG.SECONDS_PER_QUESTION;
  ui.timerValue.textContent = Math.ceil(secondsLeft);
  ui.timerPoints.textContent = calculatePoints(secondsLeft);
  ui.timerBar.style.width = `${(secondsLeft / total) * 100}%`;
  ui.timer.classList.toggle("is-warning", secondsLeft > 0 && secondsLeft <= CONFIG.WARNING_SECONDS);
}

function renderSelection(originalIndex) {
  ui.options.querySelectorAll(".option").forEach((btn) => {
    const selected = Number(btn.dataset.index) === originalIndex;
    btn.classList.toggle("is-selected", selected);
    btn.setAttribute("aria-checked", String(selected));
  });
  ui.actionBtn.disabled = false;
}

function lockOptions() {
  ui.options.querySelectorAll(".option").forEach((btn) => (btn.disabled = true));
}

function renderAnswerResult(question, selectedIndex, status, points) {
  lockOptions();
  ui.options.querySelectorAll(".option").forEach((btn) => {
    const idx = Number(btn.dataset.index);
    btn.classList.remove("is-selected");
    if (idx === question.correctAnswer) btn.classList.add("is-correct");
    else if (idx === selectedIndex) btn.classList.add("is-incorrect");
  });

  const correctText = question.options.find((o) => o.originalIndex === question.correctAnswer).text;
  const messages = {
    correct: `Resposta correta! +${points} ${points === 1 ? "ponto" : "pontos"}.`,
    incorrect: `Resposta incorreta. A resposta certa é: ${correctText}. +${points} ${points === 1 ? "ponto" : "pontos"}.`,
    timeout: `Tempo esgotado! A resposta certa é: ${correctText}.`
  };
  const classes = { correct: "is-correct", incorrect: "is-incorrect", timeout: "is-timeout" };

  ui.feedback.textContent = messages[status];
  ui.feedback.className = `feedback ${classes[status]}`;
  ui.feedback.hidden = false;
  renderSource(question.source);
  ui.questionPoints.textContent = points;
  ui.totalScore.textContent = state.totalScore;

  const isLast = state.currentIndex === state.questions.length - 1;
  ui.actionBtn.textContent = isLast ? "Ver resultado" : "Próxima pergunta";
  ui.actionBtn.disabled = false;
}

function renderSource(url) {
  if (!url) {
    ui.source.hidden = true;
    return;
  }
  let label = url;
  try {
    label = new URL(url).hostname.replace(/^www\./, "");
  } catch (err) {
    // URL inválida: mostra o texto original
  }
  ui.sourceLink.href = url;
  ui.sourceLink.textContent = label;
  ui.source.hidden = false;
}

function renderResult(summary) {
  $("result-score").textContent = state.totalScore;
  $("result-max").textContent = summary.maxScore;
  $("result-correct").textContent = summary.correct;
  $("result-wrong").textContent = summary.wrong;
  $("result-answered").textContent = summary.answered;
  $("result-timeouts").textContent = summary.timeouts;
  ui.progressBar.style.width = "100%";
}

/* =========================================================
 * Controlador do quiz
 * ========================================================= */
function currentQuestion() {
  return state.questions[state.currentIndex];
}

function loadQuestion() {
  const question = currentQuestion();
  state.status = "answering";
  state.selectedOption = null;
  renderQuestion(question, state.currentIndex, state.questions.length);
  state.questionStartedAt = Date.now();
  timer.start(CONFIG.SECONDS_PER_QUESTION, renderTimer, handleTimeout);
}

function recordResult(question, selectedAnswer, status, points, secondsLeft) {
  state.totalScore += points;
  state.results.push({
    questionId: question.id,
    selectedAnswer, // índice na lista original de alternativas (ou null)
    status, // correct | incorrect | timeout
    points,
    timeSpent: Number((CONFIG.SECONDS_PER_QUESTION - secondsLeft).toFixed(2)),
    answeredAt: new Date().toISOString()
  });
}

function selectOption(originalIndex) {
  if (state.status !== "answering") return;
  state.selectedOption = originalIndex;
  renderSelection(originalIndex);
}

function confirmAnswer() {
  if (state.status !== "answering" || state.selectedOption === null) return;

  timer.stop();
  const secondsLeft = timer.remaining();
  const question = currentQuestion();
  const correct = isCorrect(question, state.selectedOption);
  const points = correct ? calculatePoints(secondsLeft) : CONFIG.WRONG_ANSWER_POINTS;
  const status = correct ? "correct" : "incorrect";

  state.status = "answered";
  recordResult(question, state.selectedOption, status, points, secondsLeft);
  renderAnswerResult(question, state.selectedOption, status, points);
}

function handleTimeout() {
  if (state.status !== "answering") return;

  const question = currentQuestion();
  state.status = "timeout";
  recordResult(question, null, "timeout", 0, 0);
  renderAnswerResult(question, null, "timeout", 0);
}

function nextQuestion() {
  if (state.currentIndex < state.questions.length - 1) {
    state.currentIndex++;
    loadQuestion();
  } else {
    finishQuiz();
  }
}

function finishQuiz() {
  timer.stop();
  state.status = "idle";
  renderResult(getSummary());
  showScreen("result");
  saveMatch(buildMatchPayload()).catch((err) => console.error("[quiz] Falha ao salvar partida:", err));
}

function handleActionClick() {
  if (state.status === "answering") confirmAnswer();
  else if (state.status === "answered" || state.status === "timeout") nextQuestion();
}

function resetState() {
  state.currentIndex = 0;
  state.totalScore = 0;
  state.results = [];
  state.selectedOption = null;
  state.status = "idle";
  state.startedAt = new Date().toISOString();
}

async function startQuiz() {
  timer.stop();
  showScreen("loading");
  try {
    const raw = await loadQuestions();
    if (!Array.isArray(raw) || raw.length === 0) throw new Error("Nenhuma pergunta disponível.");
    state.questions = prepareQuestions(raw);
    resetState();
    showScreen("quiz");
    loadQuestion();
  } catch (err) {
    console.error("[quiz] Erro ao iniciar:", err);
    ui.errorMessage.textContent = err.message || "Tente novamente em instantes.";
    showScreen("error");
  }
}

/* =========================================================
 * Eventos
 * ========================================================= */
ui.options.addEventListener("click", (event) => {
  const btn = event.target.closest(".option");
  if (btn && !btn.disabled) selectOption(Number(btn.dataset.index));
});
ui.actionBtn.addEventListener("click", handleActionClick);
ui.startBtn.addEventListener("click", startQuiz);
ui.restartBtn.addEventListener("click", startQuiz);
ui.retryBtn.addEventListener("click", startQuiz);

// O quiz só começa quando o jogador clica em "Iniciar quiz" (tela inicial já visível no HTML).
